OKZ44 Android WebView App Project

এই প্রজেক্ট আপনার https://okz44.xo.je ওয়েবসাইটকে Android অ্যাপের ভিতরে খুলবে।
ফাইল আপলোড/প্রোফাইল ছবি নির্বাচন, লগইন সেশন কুকি, Back navigation এবং অগ্রগতি বার যুক্ত আছে।

APK তৈরির নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ZIP Extract করুন।
3. Android Studio > Open > এই OKZ44_Android_Project ফোল্ডার নির্বাচন করুন।
4. Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. app/build/outputs/apk/debug/app-debug.apk ফাইলটি পাবেন।

নোট:
- এখানে APK compile করা হয়নি; Android SDK/Gradle build environment না থাকায় Android Studio project দেওয়া হয়েছে।
- অ্যাপ চালাতে ইন্টারনেট লাগবে।
- ওয়েবসাইটের HTTPS চালু থাকতে হবে।
- আপনার ওয়েবসাইটের সার্ভার/ডাটাবেস ফিচারগুলো আলাদাভাবে কাজ করছে কি না পরীক্ষা করুন।
- Play Store-এ প্রকাশের আগে privacy policy, app signing ও target SDK requirements যাচাই করুন।
